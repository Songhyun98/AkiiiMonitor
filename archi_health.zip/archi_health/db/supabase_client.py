"""
Supabase DB 연동 모듈
수집된 데이터를 Supabase PostgreSQL에 저장
"""

from supabase import create_client, Client
from datetime import datetime


class SupabaseDB:
    """Supabase 데이터 저장소"""

    def __init__(self, url: str, key: str):
        self.client: Client = create_client(url, key)

    # ── 검색량 트렌드 ──────────────────────────────────────────
    def upsert_search_trend(self, rows: list[dict]) -> None:
        """
        search_trend 테이블에 upsert
        (같은 period + keyword_group이면 덮어쓰기)
        
        테이블 스키마:
        CREATE TABLE search_trend (
            id            SERIAL PRIMARY KEY,
            period        DATE NOT NULL,
            keyword_group TEXT NOT NULL,
            ratio         FLOAT NOT NULL,
            collected_at  TIMESTAMPTZ NOT NULL,
            UNIQUE(period, keyword_group)
        );
        """
        if not rows:
            return
        self.client.table("search_trend").upsert(
            rows, on_conflict="period,keyword_group"
        ).execute()
        print(f"  💾 search_trend {len(rows)}건 저장 완료")

    # ── 언급량 ─────────────────────────────────────────────────
    def insert_social_mention(self, rows: list[dict]) -> None:
        """
        social_mention 테이블에 insert
        
        테이블 스키마:
        CREATE TABLE social_mention (
            id           SERIAL PRIMARY KEY,
            keyword      TEXT NOT NULL,
            blog_total   INTEGER NOT NULL,
            news_total   INTEGER NOT NULL,
            collected_at TIMESTAMPTZ NOT NULL
        );
        """
        if not rows:
            return
        self.client.table("social_mention").insert(rows).execute()
        print(f"  💾 social_mention {len(rows)}건 저장 완료")

    # ── 브랜드 건강도 점수 ──────────────────────────────────────
    def insert_brand_score(self, score: dict) -> None:
        """
        brand_score 테이블에 insert
        
        테이블 스키마:
        CREATE TABLE brand_score (
            id             SERIAL PRIMARY KEY,
            week_start     DATE NOT NULL,
            search_score   FLOAT,
            mention_score  FLOAT,
            total_score    FLOAT,
            diagnosis      TEXT,
            calculated_at  TIMESTAMPTZ NOT NULL
        );
        """
        self.client.table("brand_score").insert(score).execute()
        print(f"  💾 brand_score 저장 완료 (점수: {score.get('total_score')})")

    # ── 조회 헬퍼 (분석가용) ───────────────────────────────────
    def get_recent_trends(self, weeks: int = 12) -> list[dict]:
        """최근 N주 검색량 트렌드 조회"""
        response = (
            self.client.table("search_trend")
            .select("*")
            .order("period", desc=True)
            .limit(weeks * 3)  # 3개 그룹
            .execute()
        )
        return response.data

    def get_brand_scores(self, limit: int = 12) -> list[dict]:
        """최근 브랜드 건강도 점수 이력 조회"""
        response = (
            self.client.table("brand_score")
            .select("*")
            .order("week_start", desc=True)
            .limit(limit)
            .execute()
        )
        return response.data
